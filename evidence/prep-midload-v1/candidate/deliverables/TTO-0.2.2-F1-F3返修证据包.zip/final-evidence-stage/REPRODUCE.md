# TTO独立离线复核

所有训练/协议夹具为合成；本包只交付TTO候选，服务由WS会话独立交付。先准备Python3.10隔离环境和requirements-locked.txt，安装wheels中的候选（非editable），运行pip check与scripts/check_install_identity.py。

‘python scripts/reproduce_offline.py --output /新的验证目录’运行原88项与新增回归、离线doctor、schema2模拟训练评估、历史R1-R4/R3b（正常510、冲突510排除、恢复306有效）、真实loopback协议及自身进程退出。它不访问真实设备。新合同监控服务producer 1.1.1 fixture以冻结manifest逐项核验，并由TTO Quality、Engine、Journal及正式report入口消费；16个JSON资产逐字节保留。

独立Conda安装验证需出厂Conda、匹配系统/架构的离线依赖wheelhouse和Conda本机缓存。运行verify_install.py可核对安装器。verify_platform_upgrade.py可使用baseline/TTO-v1-0.1.2-conda-install和本目录installer里的新包，在全新临时前缀重现旧配置/旧模型/旧记录升级，不对现有用户目录执行。

incremental.patch与baseline/tree可在新目录重放；patch-roundtrip.log已核对全部修改后SHA。before保存起点与旧缺口复现，退出0代表旧缺口复现成功，不代表修复通过。logs保留失败与修正后的日志。verified是最终安装候选的结果；中间包/历史服务包不能作为最终候选。

SHA256SUMS不含自身。不运行live doctor、不连接设备、不部署/重启、不调风扇、不使用CUDA、不提交或推送。

本轮有限返修位于review-repair/：repair.patch相对修复前未提交工作树，baseline/tree及repair-changes.json提供逐文件SHA和往返记录。tests/test_review_repair.py包含新记录与0.2.0已保存评分的恢复引用回归；固定历史夹具纯合成，132历史、54排除、78恢复有效只作为该夹具断言。权威最终结果以verified/、review-repair/final-*及本轮报告为准；logs/中的早期成功是历史结果，不是新候选身份。0.2.0 wheel只用于复现旧缺口。
