"""Read-only review of the frozen greybox experiment; no new model selection."""
from pathlib import Path
import hashlib,json,collections,sys,platform,importlib.metadata,os
import numpy as np
from scipy.linalg import expm
ROOT=Path(os.environ.get('TTO_REVIEW_ROOT', '/mnt/data/greybox_review_20261013'))
P=ROOT/'candidate/runs/main'
def read(p): return json.loads(Path(p).read_text())
def jl(p): return [json.loads(x) for x in Path(p).read_text().splitlines()]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x.item(),allow_nan=False)+'\n')
def field_weights(rows):
 out=np.zeros(len(rows));rr=sorted({r['run'] for r in rows if r['duration']>0})
 for run in rr:
  mm=sorted({r['macro'] for r in rows if r['run']==run and r['duration']>0})
  for macro in mm:
   ids=[i for i,r in enumerate(rows) if r['run']==run and r['macro']==macro];dt=np.array([rows[i]['duration'] for i in ids])
   if dt.sum():out[ids]=dt/dt.sum()/len(rr)/len(mm)
 return out

def matrix(m,a,E,u):
 g=a['dynamic'];pg,pc,fan=u
 if m=='G1':
  loss=g['k0']+g['k1']*fan
  M=np.zeros((2,2));M[0]=[-loss,loss*E+g['b_g']*pg+g['b_c']*pc]
 else:
  loss=g['d0']+g['d1']*fan;M=np.zeros((3,3))
  M[0]=[-g['a'],g['a'],g['b_g']*pg+g['b_c']*pc]
  M[1]=[g['c'],-g['c']-loss,loss*E]
 return M

d=read(P/'data.json');lookup={r['ref']:r for r in d['accepted']};segs={s['id']:s for s in d['segments']}
output={'environment':{'python':sys.version,'platform':platform.platform(),'dependencies':{n:importlib.metadata.version(n) for n in ['numpy','scipy','scikit-learn','pytest','threadpoolctl']}},'metrics':[],'A_long_recomputed':[],'fit_reproduction':[],'data_gaps':[],'pulse_peaks':[]}
for eid in ['F-LS','F-SL','F-POOL']:
 pred=jl(P/f'evaluation/{eid}/predictions.jsonl');cal=read(P/f'evaluation/{eid}/calibrations.json');long=jl(P/f'evaluation/{eid}/A-long.jsonl')
 # First valid nominal-or-later label, not simply an arbitrary matching temperature.
 for r in pred:
  origin=lookup[r['ref']];s=segs[r['segment']]
  ts=np.array([v['mono_s'] for v in s['rows']]);j=np.searchsorted(ts,r['t']+r['h'])
  valid=j<len(ts) and ts[j]<=r['t']+r['h']+2
  assert bool(r['label'])==valid
  if valid:
   target=s['rows'][j]
   assert target['ref']==r['label']['ref'] and target['values']['tj']==r['label']['value']
 for tab in read(P/f'evaluation/{eid}/B-metrics.json'):
  methods=list(tab['metrics']);rows=[r for r in pred if r['h']==tab['h'] and r['label'] is not None and all(m in r['B'] for m in methods)]
  if tab['scope']!='all':rows=[r for r in rows if r[tab['scope']]==tab['value']]
  cid=hashlib.sha256('\n'.join(f"{r['ref']}|{r['h']}|{r['label']['ref']}" for r in rows).encode()).hexdigest();assert cid==tab['cohort_id']
  dt=np.array([r['duration'] for r in rows]);w=dt/dt.sum() if dt.sum() else np.full(len(dt),1/len(dt));bm=field_weights(rows)
  for m,stored in tab['metrics'].items():
   e=np.array([r['B'][m]-r['label']['value'] for r in rows])
   vals={'mae':w@abs(e),'balanced_mae':bm@abs(e),'rmse':np.sqrt(w@(e*e)),'bias':w@e,'p95_abs':np.percentile(abs(e),95),'underprediction_p95':np.percentile(np.maximum(-e,0),95),'underprediction_max':np.maximum(-e,0).max()}
   assert all(abs(v-stored[k])<1e-10 for k,v in vals.items())
  if tab['scope']=='all' and tab['layer']=='all_methods':output['metrics'].append({'experiment':eid,**tab})
 for m in ['G1','G2']:
  a=read(P/f'fits/{eid}-{m}/model.json');n=1 if m=='G1' else 2;maxdiff=0;count=0;prop_count=0
  for sid,c in cal[m].items():
   s=segs[sid];t=s['timeline'];x=np.array([s['rows'][0]['values']['tj']]+([c['Ts_initial']] if n==2 else [])+[1.])
   states={0:x.copy()}
   for k,(v,z) in enumerate(zip(t,t[1:]),1):
    x=expm(matrix(m,a,c['E'],v['inputs'])*(z['t']-v['t']))@x
    states[k]=x.copy();prop_count+=1
   for row in long:
    if row['segment']!=sid:continue
    k=lookup[row['ref']]['timeline_index'];diff=abs(states[k][0]-row['A'][m]);maxdiff=max(maxdiff,diff);count+=1
   if not c.get('training_joint_initial'):
    assert c['end']-c['start']<=60+1e-8 and lookup[c['last_ref']]['mono_s']<=c['end']+1e-8
  assert maxdiff<1e-7,(eid,m,maxdiff)
  output['A_long_recomputed'].append({'experiment':eid,'model':m,'prediction_points':count,'matrix_exponentials':prop_count,'max_abs_difference_C':maxdiff})
  # Re-running the fixed experiment may choose numerically tied seeds differently.
  copy=ROOT/f'reproduced/fits/{eid}-{m}/model.json'
  rep=read(copy);diff=[]
  for k in range(1,7):
   old=read(P/f'fits/{eid}-{m}/N{k}.json');new=read(ROOT/f'reproduced/fits/{eid}-{m}/N{k}.json')
   assert new['finite'] and new['converged'];diff.append(abs(old['J']-new['J']))
  output['fit_reproduction'].append({'experiment':eid,'model':m,'attempts':6,'all_converged':True,'max_abs_J_difference':max(diff),'selected_seed_original':a['selected_seed'],'selected_seed_repeat':rep['selected_seed'],'original_dynamic':a['dynamic'],'repeat_dynamic':rep['dynamic']})
 # Same-cohort response metrics independently recomputed.
 for m in ['G1','G2']:
  vals=read(P/f'evaluation/{eid}/A-long-metrics.json')['summary'][m];e=np.array([r['A'][m]-r['label']['value'] for r in long]);dt=np.array([r['duration'] for r in long]);w=dt/dt.sum()
  assert abs(w@abs(e)-vals['mae'])<1e-10

# Explain data continuity without diagnosing ESP32/network root cause.
for r in d['runs']:
 label=r['run'];src=ROOT/'reproduced/input-cache'/('L-seven-conditions-original' if label=='L' else 'S-shortqa-original-complete');run=next(src.glob('run-*'))
 raw=jl(run/'observations-0001.jsonl');latest={};byref={};sources=collections.Counter();gaps=[]
 for z in raw:
  if z['kind'] in ['fan','temp']: latest[z['kind']]=z
  byref[z['ref']]={**latest,'event':z}
 for group in r['interval_rejections']:
  for z in group['details']:
   if z['reason']!='TTL_expires_inside_interval':continue
   cause=[];ss=byref[z['ref']]
   for field,ttl in [('fan',2.5),('temp',7.5)]:
    if field in ss and abs(ss[field]['mono_s']+ttl-z['valid_until'])<1e-6:cause.append(field)
   sources['+'.join(cause) or 'other']+=1
   gaps.append({'event_ref':z['ref'],'utc':ss['event']['received_at_utc'],'gap_to_next_event_s':z['to_t']-z['valid_until'],'expiry_cause':cause})
 ss=[s for s in d['segments'] if s['run']==label]
 output['data_gaps'].append({'run':label,'segments':len(ss),'less_than_60s':sum(s['span_s']<60 for s in ss),'less_than_60s_total_time':sum(s['span_s'] for s in ss if s['span_s']<60),'TTL_expirations':len(gaps),'sources':dict(sources),'gap_quantiles_s':np.percentile([z['gap_to_next_event_s'] for z in gaps],[0,25,50,75,100]).tolist(),'events':gaps})
# Additional descriptive short-pulse peak audit: not a new score or fitting criterion.
long=jl(P/'evaluation/F-POOL/A-long.jsonl');S=[r for r in d['runs'] if r['run']=='S'][0]
for q in S['requests']:
 rows=[r for r in long if r['run']=='S' and q['start']<=lookup[r['ref']]['wall']<=q['end']+5]
 if not rows:continue
 true=max(r['label']['value'] for r in rows);model=max(r['A']['G2'] for r in rows)
 output['pulse_peaks'].append({'request':q['id'],'points':len(rows),'window':'submit to end+5s, only existing A-long evaluation rows','TJ_peak':true,'G2_peak':model,'peak_difference_C':model-true})
# Fixed-input equilibrium is a mathematical diagnostic, not a new physical test.
output['fixed_input_equilibrium']=[]
for eid in ['F-LS','F-SL','F-POOL']:
 a=read(P/f'fits/{eid}-G2/model.json');g=a['dynamic'];Pg,Pc,u=27.,18.,.6;coef=(1+g['c']/(g['d0']+g['d1']*u))/g['a'];Q=g['b_g']*Pg+g['b_c']*Pc
 output['fixed_input_equilibrium'].append({'experiment':eid,'Pg_W':Pg,'Pc_W':Pc,'u':u,'equilibrium_Tf_minus_E_C':coef*Q,'GPU_steady_state_gain_C_per_W':coef*g['b_g'],'CPU_steady_state_gain_C_per_W':coef*g['b_c'],'interpretation':'specified constant input diagnostic; outside the short-run fitted u range; not measured equilibrium or certification'})
output['original_candidate_hashes_unchanged']=all(sha(ROOT/'candidate'/k)==v['sha256'] for k,v in read(ROOT/'candidate/SHA256.json').items())
assert output['original_candidate_hashes_unchanged']
write(ROOT/'results/independent-audit.json',output)
print('all 36 reproduced fits converged; full metric/label audit passed; all A-long responses recomputed')
print(json.dumps(output['A_long_recomputed'],indent=2))
print(json.dumps(output['pulse_peaks'],indent=2))
