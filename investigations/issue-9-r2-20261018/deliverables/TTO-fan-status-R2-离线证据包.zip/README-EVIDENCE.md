私有通讯调查证据；不要公开上传原记录/配置。
主报告在deliverables/。包含Y/M原run通讯复算子集、原始匹配TTO源码和诊断候选、16项测试与只读来源摘要。
默认无真实设备操作；重跑测试只启动127.0.0.1假服务。
根目录执行 scripts/analyze.py、scripts/phase_analysis.py、tests/loopback.py baseline/candidate、scripts/source_health.py。依赖见analysis/test-environment.txt。
scripts/verify_sources.py 另需用户原交接包的handoff/inputs ZIP，不重复装入本包。
TianshanOS仅所列参考源码，不是完整固件构建树；完整原件保留在独立工作目录。
