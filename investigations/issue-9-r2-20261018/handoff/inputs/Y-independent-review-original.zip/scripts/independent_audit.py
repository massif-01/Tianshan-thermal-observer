from pathlib import Path
import json,hashlib,zipfile,collections,csv,io,datetime,bisect,statistics,sys
import numpy as np
B=Path('/mnt/data/yet_sync_review_20261018');C=B/'candidate/thermal_yet610l_comparison_v1';R=B/'review/results';R.mkdir(parents=True,exist_ok=True)
def load(p):return json.loads(Path(p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,v):(R/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def utc(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def js(p):return [json.loads(x) for x in Path(p).read_text().splitlines()]
def stats(x):
 x=np.asarray(x,dtype=float)
 return dict(n=len(x),min=float(x.min()),max=float(x.max()),mean=float(x.mean()),p50=float(np.median(x)),p95=float(np.percentile(x,95))) if len(x) else dict(n=0)
# identity & original archives
checks=[]
for p in [Path('/mnt/data/TTO-YET610L同步短问答-冻结模型比较证据包.zip'),C/'inputs/本轮完整原始证据.zip']:
 with zipfile.ZipFile(p) as z:
  m=json.loads(z.read('SHA256.json'));err=[]
  for n,v in m['files'].items():
   data=z.read(n)
   if sha(data)!=v['sha256'] or len(data)!=v['bytes']:err.append(n)
  checks.append(dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),crc_ok=z.testzip() is None,manifest_entries=len(m['files']),mismatches=err))
p1=Path('/mnt/data/TTO-YET610L同步短问答-冻结模型比较证据包.zip');p2=Path('/mnt/data/TTO-YET610L同步短问答-冻结模型比较证据包(1).zip')
checks.append(dict(two_uploads_identical=p1.read_bytes()==p2.read_bytes(),raw_archive_embedded=True))
for name,src in [('comparison_report','/mnt/data/TTO-YET610L同步短问答-冻结模型比较报告.md'),('handoff','/mnt/data/YET-TTO-同步短问答-归档与建模交接说明.md')]:
 tgt=C/'delivery/TTO-YET610L同步短问答-冻结模型比较报告.md' if name=='comparison_report' else B/'raw/YET-TTO-同步短问答-归档与建模交接说明.md'
 checks.append(dict(name=name,standalone_matches_archive=Path(src).read_bytes()==tgt.read_bytes()))
run=next((B/'raw/remote-result/collection').glob('run-*'))
checks.append(dict(run_index_entries=len(load(run/'files.json')),mismatches=[n for n,h in load(run/'files.json').items() if sha((run/n).read_bytes())!=h]))
save('integrity.json',checks)
# repeat scientific outputs, excluding new compiler and written machine paths
frozen=C/'runs/deliverable';rep=B/'replayed';cmp=[]
for p in sorted((frozen/'results').glob('*')):
 if p.suffix not in ['.json','.jsonl'] or p.name=='build':continue
 q=rep/'results'/p.name
 if q.exists():cmp.append(dict(file=p.name,bytes_match=p.read_bytes()==q.read_bytes(),old_sha=sha(p.read_bytes()),new_sha=sha(q.read_bytes())))
cmp.append(dict(file='data.json',bytes_match=(frozen/'data.json').read_bytes()==(rep/'data.json').read_bytes()))
save('scientific_replay_comparison.json',cmp)
# raw requests plus raw SSE completion, don't equate protocol time with kernel busy
req=js(B/'raw/workload-output/requests.jsonl');obs=js(run/'observations-0001.jsonl');d=load(rep/'data.json');nodes=d['nodes'];samples=d['samples'];phases=d['phases']
print('request keys',req[0].keys())
print('first request',json.dumps(req[0],ensure_ascii=False)[:3000])
# raw measurement CSV
csvp=next((B/'raw/original-csv').glob('*.csv'));rows=list(csv.reader(io.StringIO(csvp.read_text())));header=rows[30];vals=[]
print('CSV header',header,'first data',rows[31])
for line,row in enumerate(rows[31:],32):
 if not row or not row[0]:continue
 tm=datetime.datetime.strptime(row[0]+' '+row[1],'%Y/%m/%d %H:%M:%S').replace(tzinfo=datetime.timezone(datetime.timedelta(hours=8))).timestamp()
 vals.append(dict(line=line,t=tm,temperature=float(row[2])))
assert len(vals)==2027 and all(abs(b['t']-a['t']-1)<1e-9 for a,b in zip(vals,vals[1:]))
# model supplied surface records are checked against raw by source row ordinal under offset=0.
points=js(rep/'results/surface-comparison-points.jsonl');p0=[p for p in points if p['scenario_offset_s']==0]
assert len(p0)==len(vals)
assert all(v['temperature']==p['temperature_C'] and v['t']==p['nominal_wall'] for v,p in zip(vals,p0))
save('raw_csv.json',dict(sha256=sha(csvp.read_bytes()),n=len(vals),unit='Celsius',temperature=stats([v['temperature'] for v in vals]),equal_adjacent=sum(a['temperature']==b['temperature'] for a,b in zip(vals,vals[1:])),strict_pairing_assessed=False,nominal_UTC8_matches_derived=True))
# Fan path evidence
fans=[x for x in obs if x['kind']=='fan'];ok=[x for x in fans if x.get('payload') and not x.get('error_class')];temps=[x for x in obs if x['kind']=='temp'];successful=[(x,x['payload']['data']['fans'][0]) for x in ok]
fanok=[]
for x,f in successful:
 if f['duty_valid'] is True:fanok.append(dict(t=x['mono_s'],wall=utc(x['received_at_utc']),duty=f['duty'],stale=f['temp_stale'],gain=f['controller_gain'],ref=x['ref']))
ngaps=[dict(start_ref=a['ref'],end_ref=b['ref'],return_gap_s=b['t']-a['t'],age_over_2p5_s=b['t']-a['t']-2.5) for a,b in zip(fanok,fanok[1:]) if b['t']-a['t']>2.5]
flags=collections.Counter(tuple(f[k] for k in ['mode','enabled','fault','guard_active','temp_stale','duty_valid']) for x,f in successful)
fan_audit=dict(total_requests=len(fans),successes=len(ok),timeout_errors=sum(x.get('error_class')=='TimeoutError' for x in fans),timeout_percent=100*sum(bool(x.get('error_class')) for x in fans)/len(fans),
   raw_kind_counts=dict(collections.Counter(x['kind'] for x in obs)),successful_return_intervals_s=stats(np.diff([x['t'] for x in fanok])),successful_return_gaps_gt_2p5=len(ngaps),gap_tail_durations_s=stats([g['age_over_2p5_s'] for g in ngaps]),
   observed_stale=[dict(ref=x['ref'],utc=x['received_at_utc'],duty=f['duty']) for x,f in successful if f['temp_stale']],
   actual_temp_status_records=len(temps),actual_temp_status_unhealthy=sum(x['payload']['data']['valid'] is not True or x['payload']['data']['active_source']!='variable' for x in temps),
   flags=[dict(values=k,count=v) for k,v in flags.items()],source_epochs=dict(collections.Counter(s['source_epoch'] for s in samples)),
   interpretation='Timeout/return gaps are not hundreds of physical mode changes; control/input boundary counters overlap. No cause inferred. No TTL or history changed.')
save('fan-path-audit.json',fan_audit);save('fan-validity-gaps.json',ngaps)
# overlap durations of actual reasons, excludes double counts in narrative
reason_seconds=collections.Counter();allbad=0
for a,b in zip(nodes,nodes[1:]):
 dur=b['t']-a['t']
 if not a['complete']:
  allbad+=dur
  for reason in a['reasons']:reason_seconds[reason]+=dur
save('reason_durations_overlap.json',dict(noncomplete_event_intervals_s=allbad,by_reason_s=dict(reason_seconds),overlapping=True,not_complete_TTL_tail_audit=True))
# aggregate each phase using actual accepted/raw measurements. Raw PWM time weighted within each successful-snapshot TTL only.
pr=[]
for p in phases:
 a=p['start'];b=p['end'];ss=[s for s in samples if a<=s['wall']<b];vv=[v for v in vals if a<=v['t']<b]
 fg=[f for f in fanok if a<=f['wall']<b]
 row=dict(phase=p['name'],duration_s=p['actual_s'],TJ=stats([s['values']['tj'] for s in ss]),CH1_nominal=stats([v['temperature'] for v in vv]),
  CH1_first=vv[0]['temperature'] if vv else None,CH1_last=vv[-1]['temperature'] if vv else None,
  GPU_util_sample_mean=stats([s['values']['gpu_busy'] for s in ss]),GPU_rail_sample_mean=stats([s['values']['vdd_gpu'] for s in ss]),CPU_SOC_MSS_rail_sample_mean=stats([s['values']['vdd_cpu_soc_mss'] for s in ss]),
  fan_requests=sum(a<=utc(x['received_at_utc'])<b for x in fans),fan_timeouts=sum(a<=utc(x['received_at_utc'])<b and x.get('error_class')=='TimeoutError' for x in fans),
  PWM_success_snapshot=stats([f['duty'] for f in fg]),gain_first=fg[0]['gain'] if fg else None,gain_last=fg[-1]['gain'] if fg else None,
  source_accepted=len(ss),strict_current=sum(n['complete'] for n in (nodes[s['node_index']] for s in ss)))
 pr.append(row)
save('phase_stats_raw.json',pr)
# contiguous availability: no model/mask changed. Describe only actual durations from given strict ledger.
sp=[s['span_s'] for s in d['segments']];supports=load(rep/'results/qualified-support.json')
print('supports type',type(supports))
save('native_availability.json',dict(accepted_TJ=len(samples),strict_current=d['coverage']['strict_current'],strict_segment_lengths_s=stats(sp),segments_ge60=sum(v>=60 for v in sp),source_segments=list(sorted(set(s['source_epoch'] for s in samples))),model_states={p.stem:sum(1 for _ in p.open()) for p in (rep/'results').glob('states-*.jsonl')}))
