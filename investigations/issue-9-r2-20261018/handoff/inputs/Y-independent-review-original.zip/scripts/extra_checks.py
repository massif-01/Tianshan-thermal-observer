from pathlib import Path
import json,hashlib,collections,numpy as np,datetime
B=Path('/mnt/data/yet_sync_review_20261018');C=B/'candidate/thermal_yet610l_comparison_v1';R=B/'review/results'
def ld(p):return json.loads(Path(p).read_text())
def jl(p):return [json.loads(l) for l in Path(p).read_text().splitlines()]
def sv(name,v):(R/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
a=ld(C/'runs/deliverable/data.json');b=ld(B/'replayed/data.json')
num=[];other=[];stack=[('',a,b)];n=0
while stack:
 p,x,y=stack.pop()
 if isinstance(x,dict) and isinstance(y,dict):
  if x.keys()!=y.keys():other.append((p,'keys'))
  for k in x.keys()&y.keys():stack.append((p+'/'+str(k),x[k],y[k]))
 elif isinstance(x,list) and isinstance(y,list):
  if len(x)!=len(y):other.append((p,'len'))
  for i,(xx,yy) in enumerate(zip(x,y)):stack.append((p+'/'+str(i),xx,yy))
 elif x!=y:
  if isinstance(x,(float,int)) and isinstance(y,(float,int)) and not isinstance(x,bool) and not isinstance(y,bool):num.append((p,abs(x-y)))
  else:other.append((p,x,y))
 n+=1
sv('data_semantic_comparison.json',dict(checked_fields=n,numeric_differences=len(num),max_numeric_difference=max([v for _,v in num],default=0),structural_or_text_differences=other[:20],largest_differences=sorted(num,key=lambda x:-x[1])[:20]))
req=jl(B/'raw/workload-output/requests.jsonl');phases=ld(B/'raw/checks/computer-side-verification.json')['phases'];results=[]
for r in req:
 f=B/'raw/workload-output'/f"{r['question_id']}-response.sse";text=f.read_text();parts=[];done=False
 for line in text.splitlines():
  if line.startswith('data:'):
   s=line[5:].strip()
   if s=='[DONE]':done=True
   else:parts.append(json.loads(s))
 ids={p['id'] for p in parts if 'id'in p};us=[p['usage'] for p in parts if p.get('usage')];fin=[c['finish_reason'] for p in parts for c in p.get('choices',[]) if c.get('finish_reason')]
 assert ids=={r['server_request_id']} and us[-1]==r['usage'] and fin[-1]==r['finish_reason'] and done==r['done']
 assert abs(r['end_mono_s']-r['submit_mono_s']-r['duration_seconds'])<.001
 results.append(dict(request=r['question_id'],protocol_verified=True,duration_s=r['duration_seconds'],phase=r['phase']))
assert all(x['end_mono_s']<=y['submit_mono_s'] for x,y in zip(req,req[1:]))
agg=[]
for name in ['sparse','continuous']:
 rr=[r for r in req if r['phase']==name];p=next(p for p in phases if p['name']==name);busy=sum(r['duration_seconds'] for r in rr)
 agg.append(dict(phase=name,n=len(rr),request_inflight_s=busy,phase_s=p['actual_s'],request_inflight_fraction=busy/p['actual_s'],not_gpu_busy_fraction=True))
sv('request_protocol_and_load.json',dict(requests=results,total_inflight_s=sum(x['duration_s'] for x in results),all_no_overlap=True,phase_aggregates=agg))
# context-change attribution from native raw arrival without collecting new observations
import sys
sys.path.insert(0,str(C/'vendor'))
from tto.config import load_config,merge,validate
from tto.engine import engine_for
from tto.quality import fan_data,temp_data
run=next((B/'raw/remote-result/collection').glob('run-*'));manifest=ld(run/'manifest.json');cfg=load_config(environ={});merge(cfg,manifest['config'])
for section in ['orin','tianshan']:cfg[section]['headers_file']=cfg[section]['ca_file']=None
validate(cfg);engine=engine_for(cfg,record_schema=2);counts=collections.Counter();ev=[]
for raw in jl(run/'observations-0001.jsonl'):
 old=engine.context;out=engine.process(raw);new=engine.context
 if raw['kind'] in ['fan','temp'] and old!=new:
  if raw.get('error_class'):cat='fan_http_error_to_unknown'
  elif raw['kind']=='fan' and old and old[0] is None:cat='fan_return_from_unknown'
  else:cat='other_context_difference'
  counts[cat]+=1;ev.append(dict(cat=cat,ref=raw['ref'],from_context=old,to_context=new))
sv('context_transition_causes.json',dict(counts=dict(counts),notes='Engine counter only counts some transitions; this audit records all context value transitions on every raw fan/temp record, not physical hardware changes.',events=ev))
print('data semantic',len(num),max([v for _,v in num],default=0),len(other));print('busy',agg);print('contexts',counts)
