"""Evaluation-only oracle inputs/temperature labels; the state observer never imports this module."""
import bisect, collections, hashlib, json
from pathlib import Path
import numpy as np
import greybox
from stream import jsonl
from prepare_data import write, seconds

PARAMS = ['a','c','d0','d1','b_g','b_c']


def physical_nodes(frames):
    nodes = []
    for f in frames:
        m = f['measurement']
        p, fan = m['power'], m['last_successful_pwm']
        good = bool(p and p['raw_valid'] and fan and fan['raw_valid'])
        n = dict(t=f['t'], ref=f['ref'], epoch=f['identity']['source_epoch'],
                 inputs=p['rails_W'] + [fan['value_percent']/100] if good else None,
                 valid_until=min(p['valid_until_mono_s'],fan['valid_until_mono_s']) if good else f['t'],
                 context='confirmed_normal' if f['safety']['confirmed_normal_now'] else 'observed_abnormal_or_unknown')
        if nodes and nodes[-1]['t'] == n['t']:
            nodes[-1] = n
        else:
            nodes.append(n)
    return nodes


def known_path(nodes, times, t, end):
    lo = bisect.bisect_right(times,t)-1
    hi = bisect.bisect_left(times,end)
    if lo < 0:
        return None
    edges = [t] + times[lo+1:hi] + [end]
    used = nodes[lo:hi]
    if len(used) != len(edges)-1:
        return None
    if any(n['inputs'] is None or n['valid_until'] < right-1e-9 or n['epoch'] != used[0]['epoch'] for n,right in zip(used,edges[1:])):
        return None
    return np.diff(edges),np.array([n['inputs'] for n in used]), sorted({n['context'] for n in used})


def error_stats(errors):
    e = np.array(errors, float)
    if not len(e):
        return dict(n=0, MAE_C=None, RMSE_C=None, P95_underprediction_C=None)
    under = np.maximum(-e,0)
    return dict(n=len(e), MAE_C=float(np.mean(abs(e))), RMSE_C=float(np.sqrt(np.mean(e*e))),
                mean_error_C=float(np.mean(e)), P95_abs_error_C=float(np.percentile(abs(e),95)),
                P95_underprediction_C=float(np.percentile(under,95)), max_underprediction_C=float(under.max()),
                fraction_underprediction_gt_2C=float(np.mean(under>2)))


def forecast(state, current_TJ, u, h, params):
    return float(greybox.propagate('G2',params,state[2],[h],[u],[current_TJ,state[1]])[-1,0])


def score(case, snapshots, legacy_states, data, truth_nodes, spec, out):
    out = Path(out)
    params = [spec['dynamic'][k] for k in PARAMS]
    from observer import ThermalObserver
    calc = ThermalObserver(spec)
    lookups = {m:{s['measurement']['tj']['source_ref']:s for s in ss} for m,ss in snapshots.items()}
    old = {s['ref']:s for s in legacy_states if s['model']=='primary'}
    nt = [n['t'] for n in truth_nodes]
    examples = data['examples']
    points = []
    phases = sorted({e['phase'] for e in examples})
    for e in examples:
        ref,t = e['ref'],e['t']
        for h in spec['evaluation']['horizons_s']:
            label = e['labels'][str(h)]
            row = dict(case=case, ref=ref, t=t, utc=e['utc'], phase=e['phase'], h=h,
                       label=label, label_rejection=e['label_rejections'][str(h)],
                       outcome_context=e['contexts'][str(h)],
                       A_contract=spec['evaluation']['A_contract'], methods={}, baselines={})
            if e['source_valid']:
                row['baselines']['B0'] = e['current']
                if e['slope'] is not None:
                    row['baselines']['B1'] = e['current'] + h*e['slope']
            path = known_path(truth_nodes,nt,t,t+h)
            for m, lookup in lookups.items():
                record = lookup.get(ref)
                ob = record['observer'] if record else None
                prediction = dict(phase=ob['phase'] if ob else 'unavailable', B_HOLD=None, A_recorded=None,
                                  internal_forecast_std_C=None, future_input_scenario='HOLD, not actual future load',
                                  unavailable_reason=ob['reasons'] if ob and not ob['available'] else None)
                if ob and ob['available']:
                    x = [ob['Tf_C'],ob['Ts_C'],ob['E_C']]
                    u = ob['conditional_inputs_rails_W_PWM']
                    prediction['B_HOLD'] = forecast(x,e['current'],u,h,params)
                    if path is not None:
                        dt,inputs,contexts = path
                        prediction['A_recorded'] = float(greybox.propagate('G2',params,x[2],dt,inputs,[e['current'],x[1]])[-1,0])
                        prediction['A_future_contexts'] = contexts
                    # Only the registered model/state scale, conditional on HOLD, with no claimed future-load calibration.
                    F,Q = calc._transition(float(h),float(u[2]))
                    P = np.array(ob['uncertainty']['covariance_C2'])
                    P[0,:] = P[:,0] = 0
                    P[0,0] = spec['numerical']['TJ_noise_std_C']**2
                    prediction['internal_forecast_std_C'] = float(np.sqrt(max((F@P@F.T+Q)[0,0],0)))
                row['methods'][m] = prediction
            s = old.get(ref)
            pred = dict(phase='tracking' if s else 'unavailable',B_HOLD=None,A_recorded=None,
                        protocol='original past60 state/calibration, R2 scoring contract; historical scores unchanged')
            if s:
                pred['B_HOLD'] = forecast([e['current'],s['Ts'],s['E']],e['current'],s['input_rails_W_PWM'],h,params)
                if path is not None:
                    dt,inputs,_ = path
                    pred['A_recorded'] = float(greybox.propagate('G2',params,s['E'],dt,inputs,[e['current'],s['Ts']])[-1,0])
            row['methods']['OLD60'] = pred
            points.append(row)
    jsonl(out/'predictions.jsonl',points)
    metrics=[]
    pairs=[['AUGMENTED-KF','CONDITIONAL-HOLD'],['AUGMENTED-KF','CONDITIONAL-HOLD','OLD60']]
    for kind in ['A_recorded','B_HOLD']:
        for h in spec['evaluation']['horizons_s']:
            for cohort in pairs:
                for phase in ['all']+phases:
                    for qualification in ['all_available','KF_tracking','all_methods_tracking']:
                        chosen=[r for r in points if r['h']==h and r['label'] is not None and all(b in r['baselines'] for b in ['B0','B1']) and
                                (phase=='all' or r['phase']==phase) and all(r['methods'][m][kind] is not None and
                                (qualification!='all_methods_tracking' or r['methods'][m]['phase']=='tracking') for m in cohort) and
                                (qualification!='KF_tracking' or r['methods']['AUGMENTED-KF']['phase']=='tracking')]
                        identity='\n'.join(f"{r['ref']}|{h}|{r['label']['ref']}" for r in chosen)
                        metrics.append(dict(case=case,kind=kind,h=h,phase=phase,qualification=qualification,
                                            common_methods=cohort,cohort_SHA256=hashlib.sha256(identity.encode()).hexdigest(),
                                            metrics={m:error_stats([r['methods'][m][kind]-r['label']['value'] for r in chosen]) for m in cohort},
                                            baselines={b:error_stats([r['baselines'][b]-r['label']['value'] for r in chosen if b in r['baselines']]) for b in ['B0','B1']}))
    # Context is a retrospective evaluation stratum, never an input to state or B.
    context_metrics=[]
    for h in spec['evaluation']['horizons_s']:
        for kind in ['A_recorded','B_HOLD']:
            for context in sorted({r['outcome_context'] for r in points}):
                rows=[r for r in points if r['h']==h and r['label'] is not None and r['outcome_context']==context and
                      all(b in r['baselines'] for b in ['B0','B1']) and
                      all(r['methods'][m][kind] is not None for m in ['AUGMENTED-KF','CONDITIONAL-HOLD'])]
                identity='\n'.join(f"{r['ref']}|{h}|{r['label']['ref']}" for r in rows)
                context_metrics.append(dict(case=case,h=h,kind=kind,outcome_context=context,
                    cohort_SHA256=hashlib.sha256(identity.encode()).hexdigest(),
                    metrics={m:error_stats([r['methods'][m][kind]-r['label']['value'] for r in rows]) for m in ['AUGMENTED-KF','CONDITIONAL-HOLD']},
                    baselines={b:error_stats([r['baselines'][b]-r['label']['value'] for r in rows]) for b in ['B0','B1']}))
    own=[]
    for m in ['AUGMENTED-KF','CONDITIONAL-HOLD','OLD60']:
        for kind in ['A_recorded','B_HOLD']:
            for h in spec['evaluation']['horizons_s']:
                valid=[r for r in points if r['h']==h and r['label'] is not None]
                rows=[r for r in valid if r['methods'][m][kind] is not None]
                own.append(dict(case=case,method=m,kind=kind,h=h,all_valid_TJ_denominator=sum(e['source_valid'] for e in examples),
                                per_horizon_label_denominator=len(valid), prediction_with_label=len(rows),
                                coverage_of_valid_TJ=len(rows)/sum(e['source_valid'] for e in examples),
                                coverage_of_labels=len(rows)/len(valid) if valid else None,
                                error=error_stats([r['methods'][m][kind]-r['label']['value'] for r in rows])))
    write(out/'common-metrics.json',metrics)
    write(out/'own-coverage-and-error.json',own)
    write(out/'context-common-metrics.json',context_metrics)
    coverage=[]
    for m in snapshots:
        for phase in ['all']+phases:
            refs={e['ref'] for e in examples if e['source_valid'] and (phase=='all' or e['phase']==phase)}
            used=[s for s in snapshots[m] if s['measurement']['tj']['source_ref'] in refs]
            states=collections.Counter(s['observer']['phase'] for s in used)
            available=sum(s['observer']['available'] for s in used)
            coverage.append(dict(case=case,method=m,phase=phase,all_valid_TJ=len(refs),observer_available=available,
                                 available_fraction=available/len(refs) if refs else None, phases=dict(states),
                                 tracking_fraction=states['tracking']/len(refs) if refs else None,
                                 safety_admission_claim=False))
    coverage.append(dict(case=case,method='OLD60',phase='all',all_valid_TJ=sum(e['source_valid'] for e in examples),
                         observer_available=len(old),available_fraction=len(old)/len(examples),
                         phases=dict(tracking=len(old),unavailable=len(examples)-len(old)),
                         tracking_fraction=len(old)/len(examples),protocol='legacy origin qualification only; not safety'))
    write(out/'state-coverage.json',coverage)
    return coverage,metrics,own


def reference_difference(case, snapshots, full_snapshots, windows, base, out):
    rows=[]
    for m,ss in snapshots.items():
        ref={s['measurement']['tj']['source_ref']:s for s in full_snapshots[m]}
        for s in ss:
            key=s['measurement']['tj']['source_ref']
            a,b=s['observer'],ref[key]['observer']
            t=s['generated_at_mono_s']-base
            if a['available'] and b['available']:
                rows.append(dict(method=m,ref=key,t=t,masked=any(lo<=t<hi for lo,hi in windows),
                                 Ts_difference_from_unmasked_C=a['Ts_C']-b['Ts_C'],
                                 E_difference_from_unmasked_C=a['E_C']-b['E_C'],
                                 is_true_Ts_error=False))
    jsonl(Path(out)/'difference-to-unmasked-reference.jsonl',rows)
    summaries=[]
    for m in snapshots:
        for scope in ['all','inside_mask']:
            vals=[r['Ts_difference_from_unmasked_C'] for r in rows if r['method']==m and (scope=='all' or r['masked'])]
            summaries.append(dict(case=case,method=m,scope=scope,Ts_difference=error_stats(vals),not_true_Ts_error=True))
    recovery=[]
    for lo,hi in windows:
        for m,ss in snapshots.items():
            for gate in ['available','tracking']:
                s=next((s for s in ss if s['generated_at_mono_s']>=base+hi and
                        (s['observer']['available'] if gate=='available' else s['observer']['phase']=='tracking')),None)
                recovery.append(dict(case=case,method=m,mask_end_s=hi,gate=gate,
                                     delay_s=s['generated_at_mono_s']-base-hi if s else None,
                                     recovered_ref=s['measurement']['tj']['source_ref'] if s else None))
    write(Path(out)/'reference-difference-summary.json',summaries)
    write(Path(out)/'recovery.json',recovery)


def assumption_diagnostics(snapshots, truth_nodes, out):
    """Only this evaluation function sees hidden inputs, after observer snapshots are fixed."""
    times=[n['t'] for n in truth_nodes];rows=[]
    for m,ss in snapshots.items():
        for s in ss:
            ob=s['observer']
            if not ob['available'] or not any(a['input']=='PWM' for a in ob['unknown_input_assumptions']):continue
            i=bisect.bisect_right(times,s['generated_at_mono_s'])-1
            if i<0 or truth_nodes[i]['inputs'] is None:continue
            actual=truth_nodes[i]['inputs'][2];assumed=ob['conditional_inputs_rails_W_PWM'][2]
            rows.append(dict(method=m,ref=s['measurement']['tj']['source_ref'],assumed_u=assumed,actual_u_evaluation_only=actual,
                             difference=assumed-actual,not_a_measurement_input=True))
    jsonl(Path(out)/'hidden-PWM-assumption-evaluation.jsonl',rows)
    write(Path(out)/'hidden-PWM-assumption-summary.json',
          [dict(method=m,n=len([r for r in rows if r['method']==m]),
                max_abs_fraction_error=max([abs(r['difference']) for r in rows if r['method']==m],default=None),
                hidden_values_used_for_state=False) for m in snapshots])
