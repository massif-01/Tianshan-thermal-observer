"""Package this private research handback only. No Git/network/device operations."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,tempfile,zipfile

ROOT=Path(__file__).resolve().parent
TITLE='TTO-缺测状态估计与冷启动-R2证据包.zip'
REPORT='TTO-缺测状态估计与冷启动-R2报告.md'


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def selected():
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if any(x in rel.parts for x in ['__pycache__','cache','pytest-cache']):continue
        if p.suffix in ['.so','.pyc']:continue
        if rel.parts[0]=='delivery':continue
        if rel.parts[0]=='runs':
            if len(rel.parts)<3 or rel.parts[1]!='final':continue
            if rel.parts[2]=='legacy-input':continue
            if rel.parts[2]=='old-strict-Y' and len(rel.parts)>3 and rel.parts[3]=='input':continue
        yield p


def build(target=None):
    delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True)
    # Restore code and frozen config only; raw evidence remains in the private handback archive.
    config_names={'observer-spec.json','design-freeze.json','source-registration.json','state-interface.schema.json'}
    sources=[p for p in selected() if len(p.relative_to(ROOT).parts)==1 and
             (p.suffix in ['.py','.md','.txt'] or p.name in config_names)]
    sources += [p for d in ['vendor','models','tests'] for p in (ROOT/d).rglob('*')
                if p.is_file() and p.suffix in ['.py','.json','.c'] and '__pycache__' not in p.parts]
    sources=[p for p in sources if p.name not in ['research-code.patch','protected-originals.json']]
    chunks=[]
    for p in sorted(set(sources)):
        n='experiments/thermal_state_estimation_r2/'+str(p.relative_to(ROOT))
        body=p.read_text()
        assert not body or body.endswith('\n'),p
        chunks.append('diff --git a/'+n+' b/'+n+'\nnew file mode 100644\n')
        chunks.extend(difflib.unified_diff([],body.splitlines(True),fromfile='/dev/null',tofile='b/'+n))
    patch=ROOT/'research-code.patch';patch.write_text(''.join(chunks))
    check=Path(tempfile.mkdtemp(prefix='tto-state-r2-patch-',dir='/private/tmp'))
    c=subprocess.run(['git','apply','--check',str(patch)],cwd=check,capture_output=True,text=True)
    assert c.returncode==0,c.stderr
    c=subprocess.run(['git','apply',str(patch)],cwd=check,capture_output=True,text=True)
    assert c.returncode==0,c.stderr
    for p in set(sources):
        assert sha(check/'experiments/thermal_state_estimation_r2'/p.relative_to(ROOT))==sha(p),p
    (ROOT/'patch-check.json').write_text(json.dumps(dict(status='pass',sources=len(set(sources)),source_bytes_exact=True,
        patch_sha256=sha(patch),target='new independent research directory only; no production paths'),ensure_ascii=False,indent=2)+'\n')
    shutil.copyfile(ROOT/'runs/final'/REPORT,delivery/REPORT)
    shutil.copytree(ROOT/'runs/final/figures',delivery/'figures',dirs_exist_ok=True)
    target=Path(target) if target else delivery/TITLE
    files=list(selected())
    m={'contract':'TTO-REVIEW-R2-20261018-ISSUE8-v1-private-handback',
       'scope':'Full final model-state results and reproducible code; private user inputs, never upload to GitHub.',
       'excluded_regenerable':'cache, duplicate legacy input views and old-Y extracted raw input; complete originals remain in handoff ZIPs',
       'initial_attempt':'initial point files retained in authoring checkout; index/logs/overview here, no parameter search',
       'files':{'thermal_state_estimation_r2/'+str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}}
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,'thermal_state_estimation_r2/'+str(p.relative_to(ROOT)))
        z.writestr('SHA256.json',json.dumps(m,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(m['files'])|{'SHA256.json'}
        for n,e in m['files'].items():
            b=z.read(n);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],n
    receipt=dict(status='pass',archive=target.name,bytes=target.stat().st_size,sha256=sha(target),
                 members_verified=len(m['files']),CRC='pass',report_sha256=sha(delivery/REPORT),
                 spec_sha256=sha(ROOT/'observer-spec.json'),model_sha256=sha(ROOT/'models/primary.json'),
                 runtime_sources={n:h for n,h in json.loads((ROOT/'runs/final/implementation-freeze.json').read_text())['source_SHA256'].items()},
                 patch_status='applied and source SHA exact',software_PR=False,field_run=False)
    (delivery/'SHA256.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='runtime_sources'},ensure_ascii=False))


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args();build(a.output)
