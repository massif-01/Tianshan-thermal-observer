"""Clearly synthetic known-state system; truth uses independent high-accuracy ODE integration."""
import copy, hashlib
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from observer import ThermalObserver
from stream import jsonl
from prepare_data import write
from evaluate import error_stats


def inputs(t):
    load = 100 <= t < 200 or 330 <= t < 460
    fan_high = 130 <= t < 240 or 360 <= t < 500
    return np.array([24. if load else 4., 14. if load else 6., .6 if fan_high else .2])


def synthetic_frame(t, y, u, spec, last_fan=None, fan_visible=True):
    ref = 'SYNTHETIC/observation:' + str(t)
    tj = dict(value_C=float(y), observed_mono_s=float(t), observed_utc='SYNTHETIC', source_ref=ref,
              valid_until_mono_s=float(t)+2., native_source_valid=True, age_s=0., raw_valid=True)
    power = dict(rails_W=u[:2].tolist(), names=['vdd_gpu','vdd_cpu_soc_mss'], observed_mono_s=float(t),
                 source_ref=ref, valid_until_mono_s=float(t)+2., raw_valid=True)
    if fan_visible:
        fan = dict(value_percent=float(u[2])*100, observed_mono_s=float(t), observed_utc='SYNTHETIC', source_ref=ref,
                   valid_until_mono_s=float(t)+2.5, age_s=0., raw_valid=True,
                   last_observed_flags=dict(guard_active=False,fault=False,mode='auto',enabled=True,temp_stale=False))
    else:
        fan = copy.deepcopy(last_fan)
        if fan:
            fan['raw_valid']=False
            fan['age_s']=t-fan['observed_mono_s']
    context = dict(observed_mono_s=float(t),observed_utc='SYNTHETIC',source_ref=ref,
                   valid_until_mono_s=float(t)+7.5,raw_valid=True,
                   last_observed_flags=dict(manual_mode=False,normalized_valid=True,active_source='variable',bound_variable='agx_info.temperature.tj'))
    safety=dict(guard=False if fan_visible else None,fault=False if fan_visible else None,mode='auto' if fan_visible else None,
                enabled=True if fan_visible else None,temp_stale=False if fan_visible else None,manual_mode=False,normalized_valid=True,
                active_source='variable',binding='agx_info.temperature.tj',fan_fresh=fan_visible,binding_fresh=True,
                context_changed_this_event=False,context_stable_s=float(t),confirmed_normal_now=bool(fan_visible and t>=5),unknown_is_normal=False)
    return dict(t=float(t),utc='SYNTHETIC',ref=ref,stream_started_mono_s=0.,
                identity=dict(run_id='SYNTHETIC',source_epoch=1,model_sha256=spec['model_sha256'],spec_sha256='SYNTHETIC-TEST',
                              config_sha256='SYNTHETIC',collector_source_sha256='SYNTHETIC',firmware_identity=None),
                source_reset=t==0,reset_reason='SYNTHETIC_START' if t==0 else None,new_TJ=True,
                measurement=dict(tj=tj,power=power,last_successful_pwm=fan,control_context=context),safety=safety)


def run_synthetic(spec,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    p=spec['dynamic'];summary=[]
    for E in spec['synthetic']['true_E_C']:
        seed=spec['synthetic']['seed'];rng=np.random.default_rng(seed)
        z=np.array([E+11,E+spec['synthetic']['true_Ts_minus_E_C']],float)
        records=[];streams={m:ThermalObserver(spec,m) for m in ['AUGMENTED-KF','CONDITIONAL-HOLD']}
        last_fan=None
        for t in range(spec['synthetic']['duration_s']+1):
            if t:
                u=inputs(t-1)
                def rhs(_,s):
                    d=p['d0']+p['d1']*u[2]
                    return [-p['a']*(s[0]-s[1])+p['b_g']*u[0]+p['b_c']*u[1],p['c']*(s[0]-s[1])-d*(s[1]-E)]
                z=solve_ivp(rhs,[0,1],z,rtol=1e-11,atol=1e-12).y[:,-1]
            visible=not any(lo<=t<hi for lo,hi in spec['synthetic']['mask_intervals_s'])
            frame=synthetic_frame(t,z[0]+rng.normal(0,spec['numerical']['TJ_noise_std_C']),inputs(t),spec,last_fan,visible)
            if visible:last_fan=copy.deepcopy(frame['measurement']['last_successful_pwm'])
            for method,observer in streams.items():
                snapshot=observer.step(frame);ob=snapshot['observer']
                records.append(dict(method=method,t=t,synthetic=True,true_state=[float(z[0]),float(z[1]),E],
                                    masked=not visible,phase=ob['phase'],available=ob['available'],
                                    estimated_state=[ob['Tf_C'],ob['Ts_C'],ob['E_C']],
                                    internal_std_C=ob['uncertainty']['marginal_std_C'],
                                    uncertainty_calibrated=False))
        jsonl(out/f'known-E-{E:g}.jsonl',records)
        for method in streams:
            rs=[r for r in records if r['method']==method and r['available']]
            errors=np.array([np.array(r['estimated_state'])-r['true_state'] for r in rs])
            std=np.array([r['internal_std_C'] for r in rs])
            summary.append(dict(E_truth_C=E,method=method,n=len(rs),total=spec['synthetic']['duration_s']+1,
                                errors={name:error_stats(errors[:,i]) for i,name in enumerate(['Tf','Ts','E'])},
                                empirical_fraction_within_internal_2std={name:float(np.mean(abs(errors[:,i])<=2*std[:,i])) for i,name in enumerate(['Tf','Ts','E'])},
                                is_synthetic_true_state_error=True,not_real_Ts_accuracy=True,not_calibrated_95_percent_interval=True))
    write(out/'summary.json',summary)
    return summary
