"""Verify private handoff and rebuild disposable caches for independent offline replay."""
from pathlib import Path
import hashlib, json, zipfile

ROOT=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def extract(z,path):
    assert z.testzip() is None
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    z.extractall(path)


def ensure_inputs():
    manifest=json.loads((ROOT/'handoff/SHA256.json').read_text())['files']
    for e in manifest:
        p=ROOT/'handoff'/e['path']
        assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],e['path']
    old=ROOT/'cache/old-Y-study/thermal_yet610l_comparison_v1'
    if not old.exists():
        with zipfile.ZipFile(ROOT/'handoff/inputs/Y-comparison-original.zip') as z:extract(z,old.parent)
    if not (ROOT/'cache/Y/SHA256.json').exists():
        with zipfile.ZipFile(old/'inputs/本轮完整原始证据.zip') as z:extract(z,ROOT/'cache/Y')
    if not (ROOT/'cache/M-original/trial-result.zip').exists():
        with zipfile.ZipFile(ROOT/'handoff/inputs/M-live-original.zip') as z:extract(z,ROOT/'cache/M-original')
    if not (ROOT/'cache/M/events.jsonl').exists():
        with zipfile.ZipFile(ROOT/'cache/M-original/trial-result.zip') as z:extract(z,ROOT/'cache/M')
    identity=json.loads((old/'source-identity.json').read_text())
    for n,h in identity['vendor_files'].items():assert sha(ROOT/n)==h,n
    for n,h in identity['frozen_models'].items():assert sha(ROOT/'models'/n)==h,n
    return old
