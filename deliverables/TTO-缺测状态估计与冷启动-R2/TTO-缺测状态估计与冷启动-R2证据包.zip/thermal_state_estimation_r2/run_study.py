"""Complete bounded offline Issue8 study. No device, source repair, load scheduler or training."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import argparse, copy, datetime, hashlib, json, platform, resource, shutil, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(ROOT/'cache/matplotlib')
sys.path.insert(0,str(ROOT/'vendor'))
from bootstrap_inputs import ensure_inputs,sha
from prepare_data import prepare,write
from stream import load_lines,jsonl,make_frames
from observer import ThermalObserver
from evaluate import physical_nodes,score,reference_difference,assumption_diagnostics
from synthetic import run_synthetic
import greybox
from legacy_replay import replay as legacy_replay
from legacy_trajectories import generate as legacy_generate


def observer_replay(frames,spec,out,full_interfaces=False):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    results={}
    for method in ['AUGMENTED-KF','CONDITIONAL-HOLD']:
        observer=ThermalObserver(spec,method);accepted=[];previous=None
        with (out/(method+'-interface.jsonl')).open('w') as f:
            for frame in frames:
                s=observer.step(frame)
                signature=(s['observer']['phase'],tuple(s['observer']['reasons']),json.dumps(s['safety'],sort_keys=True))
                if frame['new_TJ']:accepted.append(s)
                if full_interfaces or frame['new_TJ'] or signature!=previous:
                    f.write(json.dumps(s,ensure_ascii=False,allow_nan=False)+'\n')
                previous=signature
        jsonl(out/(method+'-accepted-states.jsonl'),accepted)
        results[method]=accepted
    return results


def legacy_view(case,rows,source,out):
    view=Path(out)/'legacy-input'/case
    run=view/'remote-result/collection'/source.name
    run.mkdir(parents=True,exist_ok=False)
    for n in ['manifest.json','input-profile.json']:
        shutil.copyfile(source/n,run/n)
    jsonl(run/'observations-0001.jsonl',rows)
    write(run/'files.json',{p.name:sha(p) for p in sorted(run.iterdir()) if p.is_file()})
    return view


def run(out):
    started=time.perf_counter();out=Path(out).resolve()
    out.mkdir(parents=True,exist_ok=False)
    old=ensure_inputs()
    spec=json.loads((ROOT/'observer-spec.json').read_text())
    freeze=json.loads((ROOT/'design-freeze.json').read_text())
    assert sha(ROOT/'observer-spec.json')==freeze['spec_sha256']
    assert sha(ROOT/'models/primary.json')==spec['model_sha256']
    initial={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file() and
             (p.relative_to(ROOT).parts[0] in ['models','vendor','handoff']) and '__pycache__' not in p.parts}
    network_attempts=[]
    def audit(event,args):
        if event in ['socket.connect','socket.getaddrinfo','socket.bind','socket.listen']:
            network_attempts.append(event);raise RuntimeError('Offline model-state research: network forbidden')
    sys.addaudithook(audit)
    def forbidden(*args,**kwargs):raise AssertionError('Frozen theta: no dynamic parameter search/training')
    greybox.fit=greybox.solve=greybox.least_squares=forbidden
    import sklearn.linear_model
    sklearn.linear_model.Ridge.fit=forbidden
    code={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*.py') if p.relative_to(ROOT).parts[0] not in ['cache','runs','handoff','delivery','publication'] and '__pycache__' not in p.parts}
    write(out/'implementation-freeze.json',dict(spec_sha256=sha(ROOT/'observer-spec.json'),source_SHA256=code,
          model_sha256=spec['model_sha256'],written_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_new_observer_scores=True))
    # Actual frozen reproduction, including its historical 0-state outcome, precedes the new observer.
    with (out/'old-strict-Y-reproduction.log').open('w') as f:
        c=subprocess.run([sys.executable,str(old/'run.py'),'--archive',str(old/'inputs/本轮完整原始证据.zip'),
                          '--output',str(out/'old-strict-Y')],stdout=f,stderr=subprocess.STDOUT)
    assert c.returncode==0,(out/'old-strict-Y-reproduction.log').read_text()
    old_summary=json.loads((out/'old-strict-Y/results/comparison-summary.json').read_text())
    assert old_summary['strict_model_states']==dict(primary=0,old_LS=0,A24=0)
    old_matches={}
    for p in (old/'runs/deliverable/results').glob('*'):
        if p.suffix in ['.json','.jsonl']:
            assert sha(p)==sha(out/'old-strict-Y/results'/p.name),p.name
            old_matches[p.name]=sha(p)
    write(out/'old-strict-reproduction.json',dict(status='pass',scientific_files_byte_exact=old_matches,
          strict_segments=352,longest_strict_segment_s=old_summary['longest_strict_segment_s'],legal_states=old_summary['strict_model_states']))
    sources,phases,masks=prepare(out/'prepared')
    full_mrows=load_lines(sources['M']/'observations-0001.jsonl')
    mmanifest=json.loads((sources['M']/'manifest.json').read_text())
    truth_frames,_=make_frames(full_mrows,mmanifest,spec)
    oracle=physical_nodes(truth_frames)
    all_coverage=[];all_metrics=[];own_scores=[];full_snapshots=None;full_data=None
    for case,meta in masks['cases'].items():
        target=out/'cases'/case
        target.mkdir(parents=True)
        visible=load_lines(out/'prepared/visible'/case/'observations.jsonl')
        view=legacy_view(case,visible,sources['M'],out)
        data=legacy_replay(view,target/'old-native-data.json',copy.deepcopy(phases['M']),'M')
        legacy_states,_,_=legacy_generate(data,target/'old60')
        frames,quality=make_frames(visible,mmanifest,spec)
        assert [f['ref'] for f in frames if f['new_TJ']]==[r['ref'] for r in data['samples'] if r['target_valid']]
        snapshots=observer_replay(frames,spec,target/'states')
        jsonl(target/'visible-native-quality.jsonl',quality)
        coverage,metrics,own=score(case,snapshots,legacy_states,data,oracle,spec,target)
        assumption_diagnostics(snapshots,oracle,target)
        all_coverage+=coverage;all_metrics+=metrics;own_scores+=own
        if case=='M_full':
            full_snapshots,full_data=snapshots,data
        else:
            assert [(r['ref'],r['labels']) for r in data['examples']]==[(r['ref'],r['labels']) for r in full_data['examples']], 'mask must not change target temperature eligibility'
            reference_difference(case,snapshots,full_snapshots,meta['windows_s'],full_mrows[0]['mono_s'],target)
        print(case,[(r['method'],r['observer_available'],r['all_valid_TJ']) for r in coverage if r['phase']=='all'],flush=True)
        assert time.perf_counter()-started<spec['budgets']['max_study_wall_s'],'frozen computational budget exhausted'
    run_synthetic(spec,out/'synthetic')
    # No M-driven retuning: this same numerical spec/config now enters Y once.
    write(out/'candidate-freeze-before-Y.json',dict(spec_sha256=sha(ROOT/'observer-spec.json'),source_SHA256=code,
           M_development_complete=True,candidate_configurations=1,retuning_or_selection_after_M=False,
           external_temperature_access_for_new_observer=False,written_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    yrows=load_lines(sources['Y']/'observations-0001.jsonl')
    ymanifest=json.loads((sources['Y']/'manifest.json').read_text())
    yframes,yquality=make_frames(yrows,ymanifest,spec)
    ydata=json.loads((out/'old-strict-Y/data.json').read_text())
    target=out/'cases/Y';target.mkdir(parents=True)
    snapshots=observer_replay(yframes,spec,target/'states',full_interfaces=True)
    assert [f['ref'] for f in yframes if f['new_TJ']]==[r['ref'] for r in ydata['samples'] if r['target_valid']]
    jsonl(target/'visible-native-quality.jsonl',yquality)
    legacy_states=load_lines(out/'old-strict-Y/results/states-causal60.jsonl')
    coverage,metrics,own=score('Y',snapshots,legacy_states,ydata,physical_nodes(yframes),spec,target)
    all_coverage+=coverage;all_metrics+=metrics;own_scores+=own
    write(out/'all-state-coverage.json',all_coverage);write(out/'all-common-metrics.json',all_metrics);write(out/'all-own-coverage-and-error.json',own_scores)
    print('Y',[(r['method'],r['observer_available'],r['all_valid_TJ']) for r in coverage if r['phase']=='all'],flush=True)
    test_env=os.environ.copy();test_env['TTO_STATE_R2_RUN']=str(out)
    c=subprocess.run([sys.executable,'-m','pytest','-q','-c','/dev/null',str(ROOT/'tests'),'-o','cache_dir='+str(out/'pytest-cache')],
                     capture_output=True,text=True,env=test_env)
    (out/'tests.log').write_text(c.stdout+c.stderr)
    assert c.returncode==0,c.stdout+c.stderr
    for n,h in initial.items():assert sha(ROOT/n)==h,n
    import numpy,scipy,matplotlib
    usage=resource.getrusage(resource.RUSAGE_SELF)
    write(out/'environment-resources.json',dict(python=sys.version,executable=sys.executable,platform=platform.platform(),
           numpy=numpy.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,
           CPU_BLAS_threads=1,CUDA=False,wall_s=time.perf_counter()-started,CPU_user_s=usage.ru_utime,
           CPU_system_s=usage.ru_stime,peak_RSS_native=usage.ru_maxrss,RSS_units='bytes on macOS; KiB on Linux',
           child_CPU_user_s=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime))
    write(out/'completion.json',dict(status='pass',contract=spec['contract'],spec_sha256=sha(ROOT/'observer-spec.json'),
           model_sha256=spec['model_sha256'],old_scientific_results_reproduced=True,source_models_raw_inputs_unchanged=True,
           network_attempts=network_attempts,theta_updates=0,E_is_boundary_state_not_theta=True,
           external_temperature_used_for_new_observer=False,real_Ts_error_claim=False,field_validation=False,
           communications_or_scheduler_modified=False,device_access=False,git_write=False,software_PR=False,
           numerical_configurations=1,stage='offline research implementation delivered, field unverified'))
    from report import make_report
    make_report(out)
    print(json.dumps(json.loads((out/'completion.json').read_text()),ensure_ascii=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.output)
