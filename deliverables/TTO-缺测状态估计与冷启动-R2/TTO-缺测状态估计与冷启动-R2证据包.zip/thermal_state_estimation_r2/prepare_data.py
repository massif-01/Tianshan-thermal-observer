"""Deterministic timing-only masks and metadata. Never select using hidden temperatures/PWM."""
from pathlib import Path
import bisect, datetime, hashlib, json
from stream import load_lines, visible_rows, jsonl

ROOT = Path(__file__).resolve().parent


def seconds(s):
    return datetime.datetime.fromisoformat(s.replace('Z', '+00:00')).timestamp()


def write(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def phases():
    events = load_lines(ROOT / 'cache/M/events.jsonl')
    ps = []
    for ev in events:
        if ev['event'] == 'phase_start':
            ps.append(dict(name=ev['phase'], start_utc=ev['occurred_at_utc'], start_ref=ev.get('ref')))
        elif ev['event'] == 'phase_end':
            next(p for p in reversed(ps) if p['name'] == ev['phase'])['end_utc'] = ev['occurred_at_utc']
    yp = json.loads((ROOT / 'cache/Y/checks/computer-side-verification.json').read_text())['phases']
    return dict(M=ps, Y=yp)


def case_masks(mrows, yrows, m_phases):
    start = mrows[0]['mono_s']
    ystart = yrows[0]['mono_s']
    fans = [r for r in yrows if r['kind'] == 'fan']
    errors = [r for r in fans if not r.get('payload') or r['payload'].get('code') != 0]
    successes = [r['mono_s'] for r in fans if r.get('payload') and r['payload'].get('code') == 0]
    bins = {}
    for r in errors:
        bins.setdefault(int((r['mono_s'] - ystart) // 60), []).append(r)
    first_bin = next(k for k in sorted(bins) if len(bins[k]) >= 2)
    base = ystart + 60 * first_bin
    cluster = []
    template = []
    for r in bins[first_bin]:
        i = bisect.bisect_right(successes, r['mono_s'])
        assert i < len(successes)
        lo, hi = max(0., r['mono_s'] - 1 - base), successes[i] - base
        cluster.append([300 + lo, 300 + hi])
        template.append(dict(error_ref=r['ref'], failure_mono_s=r['mono_s'], next_success_mono_s=successes[i], translated_interval_s=cluster[-1]))
    first_work = next(p for p in m_phases if p['name'].startswith('M'))
    transition = seconds(first_work['start_utc']) - seconds(mrows[0]['received_at_utc'])
    masks = dict(M_full=[], M_cold=[[0., 12.]], M_single=[[180.,186.]], M_cluster=cluster,
                 M_transition=[[transition-2,transition+6]], M_long=[[600.,660.]])
    manifest = dict(contract='R2-frozen-masks-v1', M_base_mono_s=start, selection='event time/type only; no PWM or temperature selection',
                    Y_template_first_bin_s=60*first_bin, Y_error_timing_template=template,
                    transition_phase=first_work, masks=masks, hidden_values_access='evaluation only')
    return masks, manifest


def prepare(out):
    out = Path(out)
    mrun = next((ROOT / 'cache/M/collection').glob('run-*'))
    yrun = next((ROOT / 'cache/Y/remote-result/collection').glob('run-*'))
    sources = dict(M=mrun, Y=yrun)
    p = phases()
    rows = {k:load_lines(v/'observations-0001.jsonl') for k,v in sources.items()}
    masks, manifest = case_masks(rows['M'], rows['Y'], p['M'])
    manifest['original_observation_SHA256'] = {k:hashlib.sha256((v/'observations-0001.jsonl').read_bytes()).hexdigest() for k,v in sources.items()}
    manifest['cases'] = {}
    for case, windows in masks.items():
        visible, hidden = visible_rows(rows['M'], windows, rows['M'][0]['mono_s'])
        path = out/'visible'/case/'observations.jsonl'
        jsonl(path, visible)
        manifest['cases'][case] = dict(windows_s=windows, hidden_original_fan_refs=hidden, hidden_count=len(hidden),
                                       visible_stream_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                       raw_original_rows=len(rows['M']), visible_rows=len(visible))
    jsonl(out/'visible/Y/observations.jsonl', rows['Y'])
    write(out/'mask-manifest.json', manifest)
    write(out/'phase-metadata.json', p)
    return sources, p, manifest


if __name__ == '__main__':
    import sys
    prepare(Path(sys.argv[1]))
