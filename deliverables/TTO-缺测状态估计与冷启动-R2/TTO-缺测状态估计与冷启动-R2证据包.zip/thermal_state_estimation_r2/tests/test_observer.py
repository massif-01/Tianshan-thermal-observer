from pathlib import Path
import copy,json,os,sys
import numpy as np
import pytest
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'vendor'))
from observer import ThermalObserver
from synthetic import synthetic_frame,inputs
from freeze import prior_from_training
from stream import load_lines,make_frames,visible_rows
from consume_example import summarize


@pytest.fixture
def spec():return json.loads((ROOT/'observer-spec.json').read_text())


def test_augmented_exact_step_matches_independent_ode(spec):
    calc=ThermalObserver(spec);state=np.array([46.,42.,35.]);u=np.array([12.,9.,.2]);p=spec['dynamic']
    def rhs(t,x):
        d=p['d0']+p['d1']*u[2]
        return [-p['a']*(x[0]-x[1])+p['b_g']*u[0]+p['b_c']*u[1],p['c']*(x[0]-x[1])-d*(x[1]-x[2]),0]
    for dt in [.0001,1.,15.,90.,300.]:
        truth=solve_ivp(rhs,[0,dt],state,rtol=1e-12,atol=1e-13).y[:,-1]
        assert np.max(abs(truth-calc.mean_step(state,u,dt)))<1e-9
        F,Q=calc._transition(dt,u[2])
        assert np.linalg.eigvalsh((Q+Q.T)/2).min()>-1e-10


def test_cold_start_uses_LS_prior_not_Tf_equilibrium_or_M(spec):
    o=ThermalObserver(spec);s=o.step(synthetic_frame(0,51.,inputs(0),spec,fan_visible=False))
    assert s['observer']['available'] and s['observer']['phase']=='provisional'
    assert s['observer']['Tf_C']==51. and s['observer']['Ts_C']!=51.
    assert s['observer']['E_C']==spec['prior']['E_mean_C'] and s['observer']['E_C']!=24
    assert s['observer']['uncertainty']['marginal_std_C'][1]>10
    assert s['measurement']['last_successful_pwm'] is None
    assert s['observer']['unknown_input_assumptions'][0]['method']=='startup_half_scale'
    m=json.loads((ROOT/'models/primary.json').read_text());p=prior_from_training(m)
    for k in m['parameters']:
        if k=='E_M' or k.startswith('Ts_M'):m['parameters'][k]=999
    assert prior_from_training(m)==p


def test_short_fan_gap_keeps_history_without_renewing_raw_PWM(spec):
    o=ThermalObserver(spec);last=None
    for t in range(25):
        f=synthetic_frame(t,46.,inputs(t),spec,last,t<20)
        if t<20:last=copy.deepcopy(f['measurement']['last_successful_pwm'])
        s=o.step(f)
    assert s['observer']['available'] and s['observer']['cold_starts']==1
    fan=s['measurement']['last_successful_pwm']
    assert fan['observed_mono_s']==19 and fan['valid_until_mono_s']==21.5 and not fan['raw_valid']
    assert s['observer']['unknown_input_assumptions'][0]['age_s']==5
    assert s['safety']['guard'] is None and not s['safety']['confirmed_normal_now']
    assert s['observer']['phase']!='tracking'


def test_long_gap_stops_and_recovers_by_new_cold_start(spec):
    o=ThermalObserver(spec);last=None
    for t in range(45):
        visible=t<20 or t==44
        f=synthetic_frame(t,46.,inputs(t),spec,last,visible)
        if visible:last=copy.deepcopy(f['measurement']['last_successful_pwm'])
        s=o.step(f)
        if 35<=t<44:
            assert s['observer']['phase']=='unavailable' and s['observer']['Ts_C'] is None
    assert s['observer']['available'] and s['observer']['cold_starts']==2
    assert s['observer']['phase']=='provisional'


@pytest.mark.parametrize('field,value',[('guard',True),('fault',True),('mode','manual'),('manual_mode',True)])
def test_explicit_safety_change_is_not_an_HTTP_gap(spec,field,value):
    o=ThermalObserver(spec)
    f=synthetic_frame(0,46.,inputs(0),spec);o.step(f)
    f=synthetic_frame(1,46.,inputs(1),spec);f['safety'][field]=value;f['safety']['confirmed_normal_now']=False
    s=o.step(f)
    assert s['observer']['phase']=='unavailable' and s['observer']['Ts_C'] is None
    assert s['safety'][field]==value


def test_binding_change_and_source_epoch_are_distinct(spec):
    o=ThermalObserver(spec)
    for t in range(12):s=o.step(synthetic_frame(t,46.,inputs(t),spec))
    f=synthetic_frame(12,46.,inputs(12),spec)
    f['safety'].update(binding='OTHER',confirmed_normal_now=False,context_changed_this_event=True)
    s=o.step(f)
    assert s['observer']['phase']!='tracking' and s['observer']['cold_starts']==1
    f=synthetic_frame(13,46.,inputs(13),spec);f['source_reset']=True;f['reset_reason']='source_epoch_changed';f['identity']['source_epoch']=2
    s=o.step(f)
    assert s['observer']['cold_starts']==2 and s['observer']['TJ_updates_since_cold_start']==1


def test_no_tick_long_interval_cannot_be_bridged_by_fresh_recovery(spec):
    o=ThermalObserver(spec)
    o.step(synthetic_frame(0,46.,inputs(0),spec))
    f=synthetic_frame(100,47.,inputs(100),spec)
    s=o.step(f)
    assert s['observer']['cold_starts']==2
    assert s['observer']['TJ_updates_since_cold_start']==1
    assert s['observer']['phase']=='provisional'
    assert s['observer']['E_C']==spec['prior']['E_mean_C']


def test_elapsed_samples_alone_do_not_resolve_latent_uncertainty(spec):
    o=ThermalObserver(spec,'CONDITIONAL-HOLD')
    for t in range(65):s=o.step(synthetic_frame(t,46.,inputs(t),spec))
    assert s['observer']['TJ_updates_since_cold_start']>60
    assert s['safety']['confirmed_normal_now']
    assert s['observer']['available'] and s['observer']['phase']=='provisional'


def real_m():
    r=next((ROOT/'cache/M/collection').glob('run-*'))
    return load_lines(r/'observations-0001.jsonl'),json.loads((r/'manifest.json').read_text())


def states(frames,spec):
    o=ThermalObserver(spec)
    return [o.step(f) for f in frames]


def test_hidden_PWM_and_whole_response_cannot_reach_quality_or_initialization(spec):
    rows,manifest=real_m();rows=rows[:430];base=rows[0]['mono_s'];windows=[[0,80]]
    a,hidden=visible_rows(rows,windows,base)
    mutated=copy.deepcopy(rows)
    for r in mutated:
        if r['ref'] in hidden:
            r['payload']={'code':0,'data':{'fans':[dict(id=0,duty=99,target_duty=99,guard_active=True,fault=True,mode='manual')], 'PRIVATE_HIDDEN_PWM':987654}}
    b,other=visible_rows(mutated,windows,base)
    assert a==b and hidden==other and hidden
    fa,qa=make_frames(a,manifest,spec);fb,qb=make_frames(b,manifest,spec)
    assert fa==fb and qa==qb and states(fa,spec)==states(fb,spec)


def test_context_confirmation_clock_does_not_count_unknown_fan_interval(spec):
    rows,manifest=real_m();rows=rows[:430];base=rows[0]['mono_s']
    projected,_=visible_rows(rows,[[30,36]],base)
    frames,_=make_frames(projected,manifest,spec)
    recovered=next(f for f in frames if f['t']>=base+36 and f['safety']['fan_fresh'] and f['safety']['binding_fresh'])
    assert recovered['safety']['context_stable_s']==0
    assert not recovered['safety']['confirmed_normal_now']
    assert all(not f['safety']['confirmed_normal_now'] for f in frames if recovered['t']<=f['t']<recovered['t']+5)
    assert any(f['safety']['confirmed_normal_now'] for f in frames if f['t']>=recovered['t']+5)


def test_future_TJ_and_surface_cannot_change_past_states(spec):
    rows,manifest=real_m();frames,_=make_frames(rows[:430],manifest,spec)
    original=states(frames,spec)
    changed=copy.deepcopy(frames)
    for i,f in enumerate(changed):
        f['external_surface_temperature_C']=-999 if i%2 else 999
        if i>=180 and f['measurement']['tj']:f['measurement']['tj']['value_C']+=50
    after=states(changed,spec)
    assert original[:180]==after[:180]
    clean=copy.deepcopy(frames)
    for f in clean:f['external_surface_temperature_C']=888
    assert original==states(clean,spec)


def test_unknown_safety_and_numeric_state_do_not_grant_field_permission(spec):
    o=ThermalObserver(spec);s=o.step(synthetic_frame(0,46.,inputs(0),spec,fan_visible=False))
    summary=summarize(s)
    assert summary['conditional_state_available'] and not summary['formal_comparison_allowed']
    assert summary['field_authorization_present'] is False and s['safety']['guard'] is None


def test_covariance_stays_PSD_through_updates_and_gaps(spec):
    o=ThermalObserver(spec);last=None
    for t in range(160):
        visible=not 50<=t<58
        f=synthetic_frame(t,46+np.sin(t/10),inputs(t),spec,last,visible)
        if visible:last=copy.deepcopy(f['measurement']['last_successful_pwm'])
        s=o.step(f)
        if s['observer']['available']:
            P=np.array(s['observer']['uncertainty']['covariance_C2'])
            assert np.linalg.eigvalsh(P).min()>-1e-10


def test_delivered_cohorts_labels_and_old_zero_result():
    path=os.environ.get('TTO_STATE_R2_RUN')
    if not path:pytest.skip('Full replay output supplied by run_study entry')
    out=Path(path)
    old=json.loads((out/'old-strict-reproduction.json').read_text())
    assert old['legal_states']==dict(primary=0,old_LS=0,A24=0)
    metrics=json.loads((out/'all-common-metrics.json').read_text())
    for r in metrics:
        counts=[v['n'] for v in r['metrics'].values()]+[v['n'] for v in r['baselines'].values()]
        assert len(set(counts))==1
    data=json.loads((out/'old-strict-Y/data.json').read_text())
    assert any(e['labels']['45'] is not None and e['labels']['90'] is None for e in data['examples'])
    snapshots=load_lines(out/'cases/Y/states/AUGMENTED-KF-accepted-states.jsonl')
    assert len(snapshots)==1843
    assert any(s['observer']['available'] for s in snapshots)
    assert all(not s['permission']['formal_field_authorized'] for s in snapshots)
