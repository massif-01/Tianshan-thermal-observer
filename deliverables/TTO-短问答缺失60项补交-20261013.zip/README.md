# 短问答归档补交

来源为本机完整原ZIP，不是截断副本。
60个文件的路径、字节和SHA逐项对应原99项索引中的缺失项。
原ZIP字节数：2390128；SHA：a560d8c03331ebb0d32f6ebefaf406efa6b951a35fddb62811aec355050bae6f。
original-SHA256.json逐字节保留原清单；complement-SHA256.json仅列这60项。
