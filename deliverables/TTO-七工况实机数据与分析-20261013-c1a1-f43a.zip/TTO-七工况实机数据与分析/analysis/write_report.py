from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,csv
root=Path(__file__).resolve().parent.parent;out=root/'analysis';d=json.loads((out/'statistics.json').read_text());tz=ZoneInfo('Asia/Shanghai')
def clock(t):return datetime.fromtimestamp(t,tz).strftime('%H:%M:%S')
def value(ph,k,stat='mean',digits=2):return f"{ph['metrics'][k][stat]:.{digits}f}"
lines=['# RM01 七个工况实机采集分析','',
'采集已停止。日期为2026年10月13日，以下时间均为北京时间。两段原始数据、操作记录和各自报告已保存，所有索引文件SHA256核验通过。本次分析直接使用当时保存的新测量和主板成功PWM，没有训练模型、回填缺口或改写历史预测。','',
'## 时间范围和分段方法','',
'- 第一段：10:22:46至10:52:46，1800秒，5572条原始记录；达到默认30分钟自动停止。',
'- 第二段：10:59:14至11:05:20，约365秒，1164条原始记录；按用户要求SIGINT停止，汇总、索引和报告均正常生成。外层Conda启动器退出码为1，不代表原始日志未完成。',
'- 两段之间缺口约388.5秒，即6分29秒。并发于10:56:35.734完成是用户提供的时间，最后约3分49秒并发和最初约2分39秒回落未被采到。',
'- 共6736条原始记录，2158个有效新TJ样本；GPU独立新鲜度检查均有效。重复主样本共5条，未重复进入统计。',
'- 工况开始和切换没有精确任务日志时，以操作记录写入时刻作为人工上报的近似分析边界。写入时刻不是精确点击或任务启动时刻。',
'- 工况4结束仅明确到10:43这个分钟。表内采用10:43:00前的明确区间，排除10:43:00至10:44:00这一不确定完成分钟；其后的未标记空档不并入其他工况。',
'- 工况7上报的是已完成卸载并进入空载，卸载起止未提供；不能据此定位或统计完整卸载过程。',
'- 以有效新样本的算术均值统计，典型间隔约1秒；不插值跨缺口。风扇采用同一run中不晚于TJ样本且年龄不超过2.5秒的有效成功duty；缺失不补0。三个功耗rail独立统计current值，不求和为整机总功耗。','',
'## 各工况温度 GPU 和风扇','',
'| 工况 | 实际统计窗口 | 有效样本 | TJ均值／已测峰值 °C | GPU均值／峰值 % | 成功PWM均值／范围 % | 风扇配对覆盖 |',
'| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for ph in d['phases']:
    lines.append(f"| {ph['id']} {ph['label']} | {clock(ph['start'])}–{clock(ph['end'])} | {ph['samples']} | {value(ph,'tj')}／{value(ph,'tj','max')} | {value(ph,'gpu')}／{value(ph,'gpu','max',0)} | {value(ph,'duty')}／{value(ph,'duty','min',0)}–{value(ph,'duty','max',0)} | {ph['fan_coverage']*100:.1f}% |")
lines+=['','工况5表内只含10:45:28至10:52:46观测部分。工况6实际只观测10:59:15至11:03:36，表中的完整工况窗口开始于用户上报的推理完成时间，其早段无数据。工况7边界是已进入空载的上报代理时间，前一窗口末尾可能已含实际卸载或空载。','',
'## 各工况独立功耗','',
'均值和峰值均为W，来自源数据的mW换算。括号内是该窗口已测峰值；源API的average字段未当作本轮窗口均值。','',
'| 工况 | VDD_GPU 均值（峰值） | VDD_CPU_SOC_MSS 均值（峰值） | VIN_SYS_5V0 均值（峰值） |',
'| --- | ---: | ---: | ---: |']
for ph in d['phases']:
    cells=[f"{value(ph,k)}（{value(ph,k,'max')}）" for k in ('gpu_power','cpu_power','vin_power')]
    lines.append(f"| {ph['id']} {ph['label']} | "+' | '.join(cells)+' |')
lines+=['',
'## 每个工况的解释','',
'1. 空载待机：TJ均值46.45°C，GPU约0%，GPU rail约1.98W，风扇18–23%。窗口只有约71秒，末尾已看到内存变化，因此不把它视为长时间稳态环境基线。',
'2. 模型拉起：系统RAM由约3.5GB增至52.9GB，期间有实际GPU活动，利用率峰值98%、GPU rail峰值39.60W，TJ峰值59.28°C。风扇短时升到75%，之后回落至18%。这段有短时高GPU功耗，不能理解为只有CPU和存储读取。',
'3. 驻模待机：整体GPU均值14.00%由末段活动抬高。10:33:25至10:34:11有47个GPU>10%的样本，峰值98%，同时功耗和温度上升。此前的明确安静部分TJ约46.40°C、GPU约0.13%、GPU rail约2.01W，PWM约18.16%。末段究竟是后台初始化、其他任务还是人工标记延迟，本轮记录不能定因，需对照任务日志。不能把整个工况3均值当作纯驻模静态成本。',
'4. 单发推理：明确窗口内GPU平均91.73%、GPU rail平均26.65W，TJ由58.34°C升至68.53°C，已测峰值69.22°C。风扇均值50.70%，存在短暂温度过期和风扇读数缺项，最低25%的部分记录不能全部解释为正常调速。',
'5. 并发推理：观测部分GPU平均92.08%、GPU rail平均27.86W，TJ由54.44°C升至69.03°C，已测峰值69.81°C，风扇均值61.34%、范围25–71%。与单发相比GPU忙碌度都接近饱和，GPU平均rail高约1.21W、PWM均值高约10.64个百分点。窗口长度、初始温度和先后顺序不同，且并发末段缺失，不能据此做同基准吞吐或散热效率比较。',
'6. 推理后待机：续录首个TJ为51.50°C，至工况7上报前为48.91°C；GPU恢复约0%，GPU rail回到1.98W，PWM从25%降至19%。最初回落未采到，不能从缺口两端重建降温速度。11:03:26已看到系统RAM约1.2GB，说明卸载后状态在工况7写入标记前已出现，不能把该阶段所有样本都当作模型仍驻留。',
'7. 卸载后空载待机：TJ由48.81°C降到48.34°C，GPU约0%、GPU rail1.98W，PWM维持19%。结束时仍比初始空载均值高约1.90°C，尚不能声称已回到相同热稳态。环境温度未测量，也不能把差值全部归因于某一个因素。','',
'## 风扇行为和数据缺项','',
'- 有效主板状态始终为AUTO，用户说明为TTI智能模式；没有观察到真实模式切换。内部controller_gain变化不等于模式变化。',
'- 模型拉起时风扇最高75%发生在约10:26:41；主板当时报告control_temperature=59.2°C、slope_c_per_min=24、predicted_temperature=77.2°C、auto_state=active。这些主板诊断说明不能只按绝对TJ比较PWM；predicted_temperature不是温度实测或已验证预测成绩。',
'- 第一段记录99次轮询漏期、6次fan请求TimeoutError、2个无效控制温度状态。漏期不是主样本缺失计数，也不能把99直接理解为99个丢失温度样本。原始日志队列丢弃为0。',
'- 四条实际fan状态报告temp_stale=true、auto_state=stale、duty=25，时间为10:34:15、10:34:22、10:49:36、10:51:24。有效返回中的fault和guard_active没有置true；不能把TTO在fan不可用时的资格诊断当作硬件风扇故障。',
'- 第二段没有轮询漏期或上述主板温度过期。原始数据可用于本次现象描述，源温度可靠性和漏读原因需要单独核对后，再安排正式模型训练或控制收益验收。',
'- 这是一段按顺序执行的热过程。没有独立重复、统一初始热状态、任务吞吐和噪声记录，不能从这轮声称并发性能、风扇降噪收益或模型预测效果。','',
'## 保存内容','',
'- 两个run目录和原始files.json哈希索引保持不变。',
'- 原轮停止后的工况5完成时间及工况6说明保存在late-operator-records.jsonl，并在续录run中关联前轮。',
'- analysis/statistics.json保存全部分阶段统计；measurements.csv保存分析所用新样本、有效GPU值和同run风扇配对。',
'- analysis/operator-records-consolidated.json保存两轮及迟报操作记录；保留原文及时间精度。',
'- analysis/condition-timeline.png和SVG为时间曲线，缺口不连线。',
'- 分析脚本保存在analysis/目录，可用同样数据离线重算，不连接设备或训练模型。','']
(out/'analysis-report.md').write_text('\n'.join(lines))
with (out/'phase-summary.csv').open('w') as f:
    names=['condition','label','start_local_approx','end_local','new_samples','tj_mean_c','tj_max_c','gpu_mean_pct','gpu_max_pct','vdd_gpu_mean_w','vdd_cpu_soc_mss_mean_w','vin_sys_5v0_mean_w','successful_duty_mean_pct','successful_duty_min_pct','successful_duty_max_pct','fan_coverage','boundary_note']
    w=csv.writer(f);w.writerow(names)
    for ph in d['phases']:
        w.writerow([ph['id'],ph['label'],clock(ph['start']),clock(ph['end']),ph['samples'],value(ph,'tj'),value(ph,'tj','max'),value(ph,'gpu'),value(ph,'gpu','max'),value(ph,'gpu_power'),value(ph,'cpu_power'),value(ph,'vin_power'),value(ph,'duty'),value(ph,'duty','min'),value(ph,'duty','max'),ph['fan_coverage'],ph['boundary']])
failed=root/'condition-6.json'
if failed.exists() and failed.read_text().startswith('Traceback'):
    failed.rename(root/'condition-6-initial-record-attempt.log')
    ops=json.loads((out/'operator-records-consolidated.json').read_text())
    resumed=next(x for x in ops if x['kind']=='condition_6_continuation_reported')
    failed.write_text(json.dumps(resumed,ensure_ascii=False,indent=2)+'\n')
print(out/'analysis-report.md')
