# YET-610L同步短问答：公开复核归档

2026-10-18；run `1ae9a7d7-bec7-4e45-a9d6-4415b4a8dece`。真实CH1 2027条、accepted TJ 1843条；352个原生严格片段最长26.013秒，未达到冻结60秒初始化。三套冻结G2合法状态均为0；严格仪表时钟配对为0，不能给G2/LP30排名或宣布Ts物理验证。全部模型deployable=false。

这是原离线研究的公开复核副本。原研究spec、三模型、33份vendor源文件、全部15份科学结果及native data.json保持身份/数值；基础设施字段脱敏及发布适配独立留痕。没有重训、放宽TTL/质量、设备访问或外部温度纠偏。原spec中禁止Git写入描述原研究阶段，本次文档发布由用户后续另行授权。

## 独立重跑

先解压本归档。使用Python 3.12、C编译器及requirements.txt中的科学库；若缺中文字体，先安装Noto Sans CJK，影响图中文字显示，不改变数值。研究依赖放在独立环境，不安装本归档中的TTO vendor副本，也不修改生产依赖。

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py --archive inputs/evidence-public.zip --output new-independent-output
```

准备依赖与实际运算分开；run.py运算阶段阻断socket连接、解析、绑定/监听并禁用动态拟合入口。输出目录必须不存在；完整入口核验公开输入ZIP的SHA/CRC/55项成员、三模型和全部vendor SHA，原生回放5319条观察，核对实际CSV逐行原值，生成所有情景/图/报告并执行8项测试。只在新输出和本研究cache写派生文件。资源值是本机离线研究，不是N305现场成绩。

## 内容与身份

- `reference-output/`：本轮原计算结果，包含native data.json、全部15份科学JSON/JSONL、三张PNG/SVG、中文报告及原测试/资源回执；三份状态文件/得分合法为空，空值及拒绝原因均保留。私有路径/执行环境字段仅作发布脱敏。
- `inputs/evidence-public.zip`：公开复核输入。保留本run的全部5319条原始观察、原生事件/评分、真实原CSV和2027行导入记录、阶段/18条请求时间、异常/恢复及测点/时钟文字证据；照片、重复服务检查快照、实测控制脚本和非必要推理正文不发布。它不冒充私有完整原包。
- 内层`PUBLIC-DERIVATION.json`及`provenance/public-input-derivation.json`：逐文件私有原件SHA、公开副本SHA、保留/省略清单。原私有输入ZIP SHA为`c0c3e1895ca9893d90a27559a491093aa4de1209ab1ae317494adc5ef3c94273`，255项已核对。真实原CSV SHA仍为`698c3842216bb34a263ba630a2760aaf9858a6232050de798d5922a47eb15e80`，未改写。
- `provenance/original-*`：原源身份、原完整研究证据ZIP身份、计算前冻结与原计算回执。它们描述原研究，不表示本公开归档逐字节等于私有包。
- `provenance/publication-adaptation.patch`：只调整公开输入SHA读取、回执字段和可移植报告；科学算法/参数/资格不变。归档格式导入脚本原作者私有默认路径改为必填`--tool`；运行入口不依赖此历史导入脚本。
- `publication-replay.json`及`publication-run/`：公开副本重跑8项测试、全部15份科学输出和native data.json与原件逐字节相等的回执；额外的最终ZIP独立解压重跑回执在GitHub报告旁的`analysis/final-archive-replay.json`。
- `research-code.patch`：可在无既有研究目录的干净检出中恢复代码/冻结JSON；不要覆盖已有研究。优先直接在本解压目录运行。
- ZIP顶层`SHA256.json`列出所有发布成员的SHA和字节数；`python -m zipfile -t evidence.zip`可检查CRC。

照片未公开，因此同框钟点的文字观察属于归档记录转述，不是公开照片复审；文字本身也没有建立仪表误差界。时间情景不是误差界，未按温度挑偏移；新环境温度未知，旧M的24°C不迁入。
